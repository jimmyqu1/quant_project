# -*- coding: utf-8 -*-
"""
Created on Thu Aug  6 19:44:07 2020

@author: liu
"""

from jqdatasdk import *
auth('','') # 填写账号密码
import pandas as pd
import numpy as np
import scipy.stats as st
import datetime
import matplotlib.pyplot as plt
import seaborn as sns

factors_data = pd.read_csv(r'C:\Users\liu\Documents\quant_project-master\hs300_data.csv',index_col=0)

factors_data = factors_data.set_index([factors_data.index,'code'])
ic_data = pd.read_csv(r'C:\Users\liu\Documents\quant_project-master\IC.csv', index_col=0)

"""
对每个时间截面计算因子的相关性，然后按时间取平均
factors_data为Multiindex DataFrame，ic_data为DataFrame
返回三个DataFrame，分别是值相关性、秩相关性和收益相关性（即IC相关性）
"""

# 获取因子名列表
factors_set = np.unique(factors_data.index.get_level_values(0))
# 创建空DataFrame用于储存相关性
value_corr = pd.DataFrame(None, index=factors_set, columns=factors_set)
rank_corr = pd.DataFrame(None, index=factors_set, columns=factors_set)
ic_corr = pd.DataFrame(None, index=factors_set, columns=factors_set)

for i in range(len(factors_set)):
    factor1 = factors_set[i]
    # 获取第一个因子的子DataFrame
    f1_data = factors_data.loc[factor1]
    for j in range(len(factors_set)):
        factor2 = factors_set[j]
        # 获取第二个因子的子DataFrame
        f2_data = factors_data.loc[factor2]
        # 计算因子之间的值相关性
        value_corr[factor1][factor2] = f1_data.corrwith(f2_data, axis=0).mean()
        # 计算因子之间的秩相关性
        rank_corr[factor1][factor2] = f1_data.rank().corrwith(f2_data.rank(), axis=0).mean()
    print('因子相关性计算进度{}/{}'.format(i+1, len(factors_set)))

#  计算因子两两之间的IC相关性
ic_corr = ic_data.corr()

print(value_corr, '\n')
print(rank_corr, '\n')
print(ic_corr, '\n')

# 热度图
fig = plt.figure(figsize=(25,25))
ax = fig.add_subplot(111)
sns.heatmap(value_corr.apply(pd.to_numeric), annot=True, vmax=1, vmin = 0)
ax.set_title("Value Correlation", fontsize=21)
fig.show()

fig = plt.figure(figsize=(25,25))
ax = fig.add_subplot(111)
sns.heatmap(rank_corr.apply(pd.to_numeric), annot=True, vmax=1, vmin = 0)
ax.set_title("Rank Correlation", fontsize=21)
fig.show()

fig = plt.figure(figsize=(25,25))
ax = fig.add_subplot(111)
sns.heatmap(ic_corr.apply(pd.to_numeric), annot=True, vmax=1, vmin = 0)
ax.set_title("Return (IC) Correlation", fontsize=21)
fig.show()

# 导出表格
value_corr.to_csv('value_corr.csv')
rank_corr.to_csv('rank_corr.csv')
ic_corr.to_csv('ic_corr.csv')